SELECT 
    herramienta,
    MIN(porcentaje_asignados) AS min_porcentaje,
    MAX(porcentaje_asignados) AS max_porcentaje
FROM microbiota_alineamiento_kraken_bowtiew2
GROUP BY herramienta;
