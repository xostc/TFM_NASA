CREATE TABLE ASTRO_diferencia_90_95 AS
SELECT 
  a.grupo_muestra,
  a.feature_type,
  a.total_muestras AS total_sin_filtro,
  b.total_muestras AS total_con_95,
  c.total_muestras AS total_con_90,
  (a.total_muestras - b.total_muestras) AS dif_sin_filtro_vs_95,
  (a.total_muestras - c.total_muestras) AS dif_sin_filtro_vs_90,
  (b.total_muestras - c.total_muestras) AS dif_95_vs_90
FROM ASTRO_clasifacion_porcentaje_feature_type AS a
JOIN ASTRO_clasifacion_95_feature_type AS b
  ON a.feature_type = b.feature_type
  AND a.grupo_muestra = b.grupo_muestra
JOIN ASTRO_clasifacion_90_gene_feature_type AS c
  ON a.feature_type = c.feature_type
  AND a.grupo_muestra = c.grupo_muestra
WHERE a.feature_type = 'gene'
ORDER BY a.grupo_muestra;
