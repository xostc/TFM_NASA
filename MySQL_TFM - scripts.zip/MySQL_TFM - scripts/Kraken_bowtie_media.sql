SELECT 
    herramienta,
    ROUND((SUM(reads_asignados) / SUM(total_reads)) * 100, 2) AS porcentaje_global
FROM microbiota_alineamiento_kraken_bowtiew2
GROUP BY herramienta;
 ### Si lo que quieres es obtener, para cada herramienta, el porcentaje global de reads asignados (calculado como el total de reads asignados dividido entre el total de reads secuenciadas) puedes agrupar los datos por la columna herramienta y utilizar funciones de agregación para sumar los valores de cada columna. Por ejemplo: