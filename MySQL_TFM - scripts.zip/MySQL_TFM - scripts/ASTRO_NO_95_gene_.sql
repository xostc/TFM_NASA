CREATE TABLE ASTRO_clasifacion_95_feature_type AS
SELECT 
  CASE 
       WHEN UPPER(muestra) LIKE '%C001%' THEN 'ASTRO_1'
       WHEN UPPER(muestra) LIKE '%C002%' THEN 'ASTRO_2'
       WHEN UPPER(muestra) LIKE '%C003%' THEN 'ASTRO_3'
       WHEN UPPER(muestra) LIKE '%C004%' THEN 'ASTRO_4'
       WHEN UPPER(muestra) LIKE '%CAPSULE%' THEN 'superficie'
       ELSE 'Otros'
  END AS grupo_muestra,
  feature_type,
  COUNT(*) AS total_muestras
FROM (
    SELECT DISTINCT 
        b.muestra, 
        b.porcentaje_asignados AS porcentaje_bowtie,
        a.porcentaje_asignadas AS porcentaje_anotacion,
        CASE 
          WHEN UPPER(b.muestra) LIKE '%L-3%' OR UPPER(b.muestra) LIKE '%L-4%' THEN 'preflight'
          WHEN UPPER(b.muestra) LIKE '%R+1%' THEN 'postflight'
          WHEN UPPER(b.muestra) LIKE '%FD3%' THEN 'inflight3'
          WHEN UPPER(b.muestra) LIKE '%FD2%' THEN 'inflight2'
          ELSE 'Sin asignar'
        END AS condicion_experimento,
        a.tipo_muestra,
        a.feature_type
    FROM microbiota_alineamiento_kraken_bowtiew2 AS b
    INNER JOIN porcentaje_anotaciones AS a 
      ON TRIM(UPPER(b.muestra)) = TRIM(UPPER(a.muestra))
    WHERE b.herramienta = 'bowtie2'
      AND a.porcentaje_asignadas >= 95
) AS sub
GROUP BY grupo_muestra, feature_type
ORDER BY grupo_muestra, feature_type;
