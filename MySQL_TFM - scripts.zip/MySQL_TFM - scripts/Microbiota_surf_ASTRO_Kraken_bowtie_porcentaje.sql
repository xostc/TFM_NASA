CREATE TABLE ASTRO_Kraken_bowtie_porcentaje AS
SELECT 
  CASE 
    WHEN UPPER(muestra) LIKE '%C001%' THEN 'ASTRO_1'
    WHEN UPPER(muestra) LIKE '%C002%' THEN 'ASTRO_2'
    WHEN UPPER(muestra) LIKE '%C003%' THEN 'ASTRO_3'
    WHEN UPPER(muestra) LIKE '%C004%' THEN 'ASTRO_4'
    WHEN UPPER(muestra) LIKE '%CAPSULE%' THEN 'superficie'
    ELSE 'Otros'
  END AS grupo_muestra,
  herramienta,
  ROUND(AVG(porcentaje_asignados), 2) AS media_porcentaje_asignados,
  COUNT(*) AS total_muestras
FROM microbiota_alineamiento_kraken_bowtiew2
GROUP BY grupo_muestra, herramienta
ORDER BY grupo_muestra, herramienta;
