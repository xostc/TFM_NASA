-- Ver el rango de porcentajes en la tabla de alineamiento
SELECT MIN(porcentaje_asignados) AS min_porcentaje, MAX(porcentaje_asignados) AS max_porcentaje
FROM microbiota_alineamiento_kraken_bowtiew2;

-- Ver el rango de porcentajes en la tabla de anotaciones
SELECT MIN(porcentaje_asignadas) AS min_porcentaje, MAX(porcentaje_asignadas) AS max_porcentaje
FROM porcentaje_anotaciones;
