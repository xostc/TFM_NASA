CREATE TABLE Muestras_descartadas_filtro_90 AS
SELECT 
  s.muestra,
  CASE 
    WHEN UPPER(s.muestra) LIKE '%C001%' THEN 'ASTRO_1'
    WHEN UPPER(s.muestra) LIKE '%C002%' THEN 'ASTRO_2'
    WHEN UPPER(s.muestra) LIKE '%C003%' THEN 'ASTRO_3'
    WHEN UPPER(s.muestra) LIKE '%C004%' THEN 'ASTRO_4'
    WHEN UPPER(s.muestra) LIKE '%CAPSULE%' THEN 'superficie'
    ELSE 'Otros'
  END AS grupo_muestra,
  s.feature_type,
  s.porcentaje_asignadas,
  'Descartada por 90%' AS criterio
FROM porcentaje_anotaciones s
WHERE s.feature_type = 'gene'
  AND s.porcentaje_asignadas >=  90
ORDER BY grupo_muestra, criterio, s.muestra;