SELECT 
    CASE 
         WHEN UPPER(muestra) LIKE '%C001%' THEN 'ASTRO_1'
         WHEN UPPER(muestra) LIKE '%C002%' THEN 'ASTRO_2'
         WHEN UPPER(muestra) LIKE '%C003%' THEN 'ASTRO_3'
         WHEN UPPER(muestra) LIKE '%C004%' THEN 'ASTRO_4'
         WHEN UPPER(muestra) LIKE '%CAPSULE%' THEN 'superficie'
         WHEN UPPER(muestra) LIKE '%145_%' THEN 'petri'
         WHEN UPPER(muestra) LIKE '%FLT%' THEN 'spaceflight'
         WHEN UPPER(muestra) LIKE '%GC2%' THEN 'ground'
         ELSE 'Otros'
    END AS grupo_muestra,
    COUNT(*) AS total_muestras
FROM (
    SELECT DISTINCT 
        b.muestra, 
        b.porcentaje_asignados AS porcentaje_bowtie,
        a.porcentaje_asignadas AS porcentaje_anotacion,
        CASE 
          WHEN UPPER(b.muestra) LIKE '%L-3%' OR UPPER(b.muestra) LIKE '%L-4%' THEN 'preflight'
          WHEN UPPER(b.muestra) LIKE '%R+1%' THEN 'postflight'
          WHEN UPPER(b.muestra) LIKE '%FD3%' THEN 'inflight3'
          WHEN UPPER(b.muestra) LIKE '%FD2%' THEN 'inflight2'
		  WHEN UPPER(b.muestra) LIKE '%FLT%' THEN 'spaceflight'
          WHEN UPPER(b.muestra) LIKE '%GC2%' THEN 'ground'
          ELSE 'Sin asignar'
        END AS condicion_experimento,
        a.tipo_muestra,
        a.feature_type
    FROM microbiota_alineamiento_kraken_bowtiew2 AS b
    INNER JOIN porcentaje_anotaciones AS a 
        ON TRIM(UPPER(b.muestra)) = TRIM(UPPER(a.muestra))
    WHERE b.herramienta = 'bowtie2'
) AS sub
GROUP BY grupo_muestra
ORDER BY grupo_muestra;
