SELECT DISTINCT 
    b.muestra, 
    b.porcentaje_asignados AS porcentaje_bowtie,
    a.porcentaje_asignadas AS porcentaje_anotacion,
    CASE 
      WHEN UPPER(b.muestra) LIKE '%L-3%' OR UPPER(b.muestra) LIKE '%L-4%' THEN 'preflight'
      WHEN UPPER(b.muestra) LIKE '%R+1%' THEN 'postflight'
      WHEN UPPER(b.muestra) LIKE '%FD3%' THEN 'inflight3'
      WHEN UPPER(b.muestra) LIKE '%FD2%' THEN 'inflight2'
      ELSE 'Sin asignar'
    END AS condicion_experimento,
    a.tipo_muestra,
    a.feature_type
FROM microbiota_alineamiento_kraken_bowtiew2 AS b
INNER JOIN porcentaje_anotaciones AS a 
    ON TRIM(UPPER(b.muestra)) = TRIM(UPPER(a.muestra))
WHERE b.herramienta = 'bowtie2'
  AND a.porcentaje_asignadas >=  90
ORDER BY condicion_experimento;

###Aquí te propongo una consulta modificada para que puedas identificar las muestras que se descartan
###según el criterio de porcentaje de anotación (es decir, aquellas que tienen a.porcentaje_asignadas < 90) y, 
 ###además, que en la tabla microbiota_alineamiento_kraken_bowtiew2 se incluya únicamente la herramienta "bowtie2" 
 ###en la condición, en lugar de usar la condición de que b.porcentaje_asignados sea mayor o igual a 100.